package dictionary;

public class Word {

    public String spelling;
    public String explain;

    Word(String spelling, String explain){
        this.spelling = spelling;
        this.explain = explain;
    }
    Word(){
        this.spelling = spelling;
        this.explain = explain;
    }
    public String printWord(){
        return spelling  + explain;
    }

}

