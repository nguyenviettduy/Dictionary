package dictionary;

public class MainDictionary {

    public static void main(String[] args) {

        DictionaryCommand_Line dCL = new DictionaryCommand_Line();
        dCL.dictionaryBasic();
    }
}
