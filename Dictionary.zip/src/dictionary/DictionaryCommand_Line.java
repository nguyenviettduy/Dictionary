package dictionary;

public class DictionaryCommand_Line {
    public void dictionaryBasic(){
        DictionaryManagement dM = new DictionaryManagement();
        DictionaryCommandline dC = new DictionaryCommandline();
        dM.insertFromCommandline();
        dC.showAllWords();
    }
}
