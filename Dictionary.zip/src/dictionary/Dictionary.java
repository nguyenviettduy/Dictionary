package dictionary;

import java.util.ArrayList;

public class Dictionary {
    ArrayList<Word> Words = new ArrayList<>();
}
