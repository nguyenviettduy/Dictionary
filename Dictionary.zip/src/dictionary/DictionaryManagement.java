package dictionary;

import java.util.Scanner;

public class DictionaryManagement {

    public void insertFromCommandline(){
        Scanner scan = new Scanner(System.in);
        Dictionary dictionary = new Dictionary();

        int amountWord = scan.nextInt();
        for(int i=0;i<amountWord;i++){
            String s1,s2;
            s1 = scan.nextLine(); s2 = scan.nextLine();
            Word w = new Word(s1,s2);
            dictionary.Words.add(w);

        }
//        for (Word w : dictionary.Words){
//            System.out.println(w.printWord());
//        }
    }
}
