package dictionary;

public class DictionaryCommandline {
    public static void showAllWords(){
        Dictionary dictionary = new Dictionary();
        for (Word w : dictionary.Words){
            System.out.println(w);
        }
    }
}
